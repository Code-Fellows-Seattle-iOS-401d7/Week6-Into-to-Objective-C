//
//  ViewController+Swizzle.m
//  SingleViewApp
//
//  Created by Adam Wallraff on 11/18/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "ViewController+Swizzle.h"
#import <objc/runtime.h>

@implementation ViewController (Swizzle)

-(void)xxx_viewWillAppear:(BOOL)animated{
//    [self xxx_viewWillAppear:animated];
    
    CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height /2 );
    
    UIView *topView = [[UIView alloc]initWithFrame:frame];
    
    topView.backgroundColor = [UIColor darkGrayColor];
    
    [self.view addSubview:topView];
    
    NSLog(@"You got swizzled!");//ADDED
    
}


+(void)load{ //CLASS Method not instance method
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        Class class = [self class];
        
        SEL originalSelector = @selector(viewWillAppear:);
        SEL swizzledSelector = @selector(xxx_viewWillAppear:);
        
        Method originalMethod = class_getInstanceMethod(class, originalSelector);
        Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
        
        BOOL didAddMethod =class_addMethod(class,
                                            swizzledSelector, //Swizzled - not original
                                            method_getImplementation(swizzledMethod),//Swizzled - not original
                                            method_getTypeEncoding(swizzledMethod)); //Swizzled - not original
        
        
        if(didAddMethod){
            class_replaceMethod(class,
                                swizzledSelector,
                                method_getImplementation(originalMethod),
                                method_getTypeEncoding(originalMethod));
        } else {
            method_exchangeImplementations(originalMethod, swizzledMethod);
        }
        
        
        
    });
    
    
}




@end
