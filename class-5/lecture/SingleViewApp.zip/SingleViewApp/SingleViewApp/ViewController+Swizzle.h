//
//  ViewController+Swizzle.h
//  SingleViewApp
//
//  Created by Adam Wallraff on 11/18/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (Swizzle)

@end
